import React, { Component } from "react";
import { StyleSheet, Text, View, TextInput, Button, Alert } from "react-native";
import ListItem from "./components/ListItem";
export default class App extends Component {
    state = {
        courseName: "",
        courses: [],
    };
    placeCourseName = text => {
        this.setState({ courseName: text });
    };
    addOnPress = () => {
        if (this.state.courseName.trim() === "") {
            return;
        }
        this.setState(prevState => {
            return {
                courses: prevState.courses.concat(prevState.courseName),
            };
        });
    };

    render() {
        const outputCourse = this.state.courses.map((course, i) => (
            <ListItem
                key={i}
                courseName={course}
                onItemPressed={() => alert("item Pressed with id :" + i)}
            />
        ));
        // const placesOutput = this.state.places.map((place, i) => (
        //     <ListItem key={i} placeName={place} />
        //   ));
        return (
            <View style={styles.container}>
                <Text>Muzamil Project</Text>
                <View style={styles.inputcontainer}>
                    <TextInput
                        placeholder="Add here"
                        placeholderTextColor="grey"
                        style={styles.textplace}
                        value={this.state.courseName}
                        onChangeText={this.placeCourseName}
                    />
                    <Button
                        title="Add"
                        onPress={this.addOnPress}
                        style={styles.buttonplace}
                    />
                </View>

                <View style={styles.listplace}>{outputCourse}</View>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 26,
        backgroundColor: "#fff",
        alignItems: "center",
        justifyContent: "flex-start",
    },
    inputcontainer: {
        flexDirection: "row",
        width: "100%",
        padding: 3,
        backgroundColor: "#fff",
        alignItems: "center",
        justifyContent: "space-between",
    },
    textplace: {
        padding: 5,
        width: "70%",
        borderColor: "red",
        borderRadius: 7,
        borderWidth: 1,
    },
    buttonplace: {
        width: "30%",
    },
    listplace: {
        width: "100%",
    },
});
