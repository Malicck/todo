import React, { Component } from "react";
import { StyleSheet, View, Text, TouchableOpacity } from "react-native";

const listItem = props => (
    <TouchableOpacity onPress={props.onItemPressed}>
        <View style={styles.container}>
            <Text>{props.courseName}</Text>
        </View>
    </TouchableOpacity>
);

const styles = StyleSheet.create({
    container: {
        backgroundColor: "#eee",
        padding: 5,
        marginBottom: 10,
        width: "100%",
        justifyContent: "center",
        alignItems: "center",
    },
});
export default listItem;
